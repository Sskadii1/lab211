package manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ManageEastAsiaCountries {
    private List<EastAsiaCountries> countryList = new ArrayList<>();

    public void addCountryInformation(EastAsiaCountries country) {
        countryList.add(country);
    }

    public void displayRecentlyEnteredInformation() {
        if (countryList.isEmpty()) {
            System.out.println("No countries have been entered yet.");
        } else {
            System.out.println("Recently Entered Countries:");
            countryList.forEach(EastAsiaCountries::display);
        }
    }

    public EastAsiaCountries[] searchInformationByName(String name) {
        
        return countryList.stream()
                
                .filter(country -> country.countryName.equalsIgnoreCase(name))
                
                .toArray(EastAsiaCountries[]::new);
    }

   public void sortInformationByAscendingOrder() {
       
    if (countryList.isEmpty()) {
        
        System.out.println("No countries to sort.");
        
    } else {
        
        Collections.sort(countryList, Comparator.comparing(country 
                -> country.countryName));
        System.out.println("Countries sorted by name in ascending order:");
        countryList.forEach(EastAsiaCountries::display);
    }
}
}
