package pkg00534;

import manager.ManageEastAsiaCountries;
import manager.EastAsiaCountries;
import java.util.Scanner;
import manager.EastAsiaCountries;

public class Main {

   public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    ManageEastAsiaCountries manager = new ManageEastAsiaCountries();
    
    boolean exit = false; // Flag to control loop termination
    
    while (!exit) { // Continue until exit flag is set to true
        System.out.println("1. Add a country");
        System.out.println("2. Display entered information");
        System.out.println("3. Search by country name");
        System.out.println("4. Sort by country name");
        System.out.println("5. Exit");
        System.out.print("Select an option: ");
        
        int choice = getIntInput(scanner);

        switch (choice) {
            case 1:
                EastAsiaCountries country = getCountryFromInput(scanner);
                System.out.println("Country object created: " + country);
                manager.addCountryInformation(country);
                System.out.println("Country added to manager.");
                break;
            case 2:
                manager.displayRecentlyEnteredInformation();
                break;
            case 3:
                System.out.print("Enter the country name to search: ");
                String searchName = scanner.next();
                displaySearchResults(manager.searchInformationByName(searchName));
                break;
            case 4:
                manager.sortInformationByAscendingOrder();
                break;
            case 5:
                System.out.println("Exiting program.");
                exit = true; // Set the exit flag to true to terminate the loop
                break;
            default:
                System.out.println("Invalid option. Please choose a valid option (1-5).");
        }
    }
    scanner.close(); // Close the scanner when done
}

    private static int getIntInput(Scanner scanner) {
        int input = -1;
        while (input < 1 || input > 5) {
            if (scanner.hasNextInt()) {
                input = scanner.nextInt();
            } else {
                System.out.println("Invalid input. Please enter a number (1-5).");
                scanner.next(); // Clear the invalid input
            }
        }
        return input;
    }

    private static EastAsiaCountries getCountryFromInput(Scanner scanner) {
        System.out.println("Enter the information for a country:");
        System.out.print("Country Code: ");
        String countryCode = scanner.next();
        System.out.print("Country Name: ");
        String countryName = scanner.next();
        float totalArea = getFloatInput(scanner, "Total Area (sq. km): ");
        System.out.print("Terrain: ");
        String terrain = scanner.next();
        // Debug print statements
        System.out.println("Country Code: " + countryCode);
        System.out.println("Country Name: " + countryName);
        System.out.println("Total Area: " + totalArea);
        System.out.println("Terrain: " + terrain);
        return new EastAsiaCountries(countryCode, countryName, totalArea, terrain);
    }

    private static float getFloatInput(Scanner scanner, String prompt) {
        float input = -1;
        while (input <= 0) {
            System.out.print(prompt);
            if (scanner.hasNextFloat()) {
                input = scanner.nextFloat();
                if (input <= 0) {
                    System.out.println("Invalid input. Please enter a positive number.");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next(); // Clear the invalid input
            }
        }
        return input;
    }

    private static void displaySearchResults(EastAsiaCountries[] results) {
        if (results.length == 0) {
            System.out.println("Country not found.");
        } else {
            System.out.println("Search result:");
            for (EastAsiaCountries result : results) {
                result.display();
            }
        }
    }
}
