
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Admin
 */
public class Validate {

    Scanner sc = new Scanner(System.in);

    public int inputInt(String msg, int min, int max) {

        System.out.print(msg);

        while (true) {

            String input = sc.nextLine();
            try {

                int number = Integer.parseInt(input);

                if (number > max || number < min) {
                    System.out.println("re-input");
                    continue;
                }
                return number;

            } catch (NumberFormatException ex) {
                System.out.println("re-input");
            }
        }
    }

    public double inputDouble(String msg, double min, double max) {
        System.out.print(msg);

        while (true) {

            String input = sc.nextLine();

            try {
                double number = Double.parseDouble(input);

                if (number > max || number < min) {
                    System.out.println("re-input");
                    continue;
                }

                return number;
            } catch (NumberFormatException ex) {
                System.out.println("re-input");

            }

        }

    }

    public String inputString(String msg){
        System.out.print(msg);
        
        while(true){
            String input = sc.nextLine();
            
            if(input.isEmpty()){
                System.out.println("re-input string");
                continue;
            }
            
            
            return input;
            
        }
    }
    
    
    
    
    
    
    
    
}
