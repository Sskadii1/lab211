package pkg0072v2;

// UserManager.java
import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private Map<String, User> users = new HashMap<>();

    public void addUser(String username, String password, String email, String phone) throws Exception {
        if (users.containsKey(username)) {
            throw new Exception("Username already exists");
        }
        if (!Validation.isValidEmail(email)) {
            throw new Exception("Invalid email format");
        }
        if (!Validation.isValidPhone(phone)) {
            throw new Exception("Invalid phone number");
        }
        users.put(username, new User(username, password));
    }

    public User getUser(String username) {
        return users.get(username);
    }
}


