package pkg0072v2;

// Main.java
import java.util.Scanner;

public class Main {
    private static UserManager userManager = new UserManager();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("super md5 enc");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("your choices :");
            int option = scanner.nextInt();
            scanner.nextLine(); // consume newline
            if (option == 1) {
                register();
            } else if (option == 2) {
                login();
            } else if (option == 3) {
                break;
            }
        }
    }

    private static void register() {
        String username = "";
        while (true) {
            System.out.print("Enter username: ");
            username = scanner.nextLine();
            if (username.isEmpty()) {
                System.out.println("Username cannot be empty");
            } else {
                break;
            }
        }

        String password = "";
        while (true) {
            System.out.print("Enter password: ");
            password = scanner.nextLine();
            if (password.isEmpty()) {
                System.out.println("Password cannot be empty");
            } else {
                break;
            }
        }

        String email = "";
        while (true) {
            System.out.print("Enter email: ");
            email = scanner.nextLine();
            if (!Validation.isValidEmail(email)) {
                System.out.println("Invalid email format");
            } else {
                break;
            }
        }

        String phone = "";
        while (true) {
            System.out.print("Enter phone: ");
            phone = scanner.nextLine();
            if (!Validation.isValidPhone(phone)) {
                System.out.println("Invalid phone number");
            } else {
                break;
            }
        }

        try {
            userManager.addUser(username, password, email, phone);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        User user = userManager.getUser(username);
        if (user != null && user.getPassword().equals(password)) {
            System.out.println("Hello " + username);
        } else {
            System.out.println("Invalid username or password");
        }
    }
}
