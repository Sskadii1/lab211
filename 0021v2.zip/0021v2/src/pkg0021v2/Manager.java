package pkg0021v2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;




class Manager {
    List<Student> students = new ArrayList<>();
    Validate validate = new Validate();
    
   
    
    Scanner sc = new Scanner(System.in);

    
    
    
  public void create() {
    String id = validate.inputString("Enter Student ID: ");

    // Check if a student with the same ID already exists
    for (Student student : students) {
        if (student.getId().equals(id)) {
            // Check if the student is already learning the same class in the same semester
            String semester = validate.inputString("Enter Student Semester: ");
            String courseName = validate.checkInputCourse("Enter Course Name (java, .net, c/c++): ");
            if (student.getSemester().equals(semester) && student.getCourseName().equalsIgnoreCase(courseName)) {
                System.out.println("Student with the same ID, semester, and course already exists.");
                return;
            }
        }
    }

    String name = validate.inputString("Enter Student Name: ");

    String semester = validate.inputString("Enter Student Semester: ");
    String courseName = validate.checkInputCourse("Enter Course Name (java, .net, c/c++): ");

    students.add(new Student(id, name, semester, courseName));
    System.out.println("Student added successfully.");
}




    
    
    
    

    void findAndSort() {
    String searchString = validate.inputString("Enter a substring to search for in names: ");
    
    List<Student> matchedStudents = new ArrayList<>();
    
    // Find students whose names contain the entered substring
    for (Student student : students) {
        if (student.getName().toLowerCase().contains(searchString.toLowerCase())) {
            matchedStudents.add(student);
        }
    }
    
    if (matchedStudents.isEmpty()) {
        System.out.println("No student found with name containing \"" + searchString + "\"");
        return;
    }
    
    // Sort matched students by name
    matchedStudents.sort(Comparator.comparing(Student::getName));
    
    // Print sorted matched students
    for (Student s : matchedStudents) {
        System.out.println("ID: " + s.getId() 
                + ", NAME: " + s.getName() 
                + ", SEMESTER: " + s.getSemester() 
                + ", COURSENAME: " + s.getCourseName());
    }
}

    
    
    
        
        
     void updateOrDelete() {
    String id = validate.inputString("Enter Student ID: ");
    List<Student> studentsWithSameId = new ArrayList<>();

    // Find students in the list with the same ID
    for (Student s : students) {
        if (s.getId().equals(id)) {
            studentsWithSameId.add(s);
        }
    }

    if (!studentsWithSameId.isEmpty()) {
        // Display the list of students with the same ID
        System.out.println("Students with ID " + id + ":");
        for (int i = 0; i < studentsWithSameId.size(); i++) {
            Student s = studentsWithSameId.get(i);
            System.out.println((i + 1) 
                    + ". ID: " + s.getId() 
                    + ", Name: " + s.getName() 
                    + ", Semester: " + s.getSemester() 
                    + ", Course Name: " + s.getCourseName());
        }

        // Ask the user to select the student to update
        int choice = validate.inputInt(
                "Enter the index of the student you want to update: ",
                1, studentsWithSameId.size()) - 1;
        Student found = studentsWithSameId.get(choice);

        // Display the selected student's information
        System.out.println("Student selected:");
        System.out.println("ID: " 
                + found.getId() 
                + ", Name: " 
                + found.getName() 
                + ", Semester: " 
                + found.getSemester() 
                + ", Course Name: " 
                + found.getCourseName());

        // Ask whether to update or delete the student
        if (validate.checkUD("Do you want to update (U) or delete (D) student?")) {
            // Update information
            String semester = validate.inputString("Enter new Student Semester: ");
            String courseName = validate.checkInputCourse("Enter new Course Name (java, .net, c/c++): ");

            // Update selected student's information
            found.setSemester(semester);
            found.setCourseName(courseName);

            System.out.println("Student updated successfully.");
        } else {
            // Delete the selected student
            students.remove(found);
            System.out.println("Student deleted successfully.");
        }
    } else {
        System.out.println("No student found with ID " + id);
    }
}



    
    
    void report() {
        Map<String, Integer> report = new HashMap<>();

        for (Student student : students) {
            String i = student.getName() + " | " + student.getCourseName();
            report.put(i, report.getOrDefault(i, 0) + 1);
            
        }

        
        
        
        for (Map.Entry<String, Integer> s : report.entrySet()) {
            
            String[] a = s.getKey().split(" \\| ");
            String nameo = a[0];
            String nameco = a[1];
            int totalCourses = s.getValue();
            
            System.out.println(nameo + " | " + nameco + " | " + totalCourses);
        }
    }
    
    
    
    
}

    

    

  

  
