package pkg0021v2;

// ... (existing imports)

public class Main {
    public static void main(String[] args) {
        Manager manager = new Manager();
        while (true) {
            System.out.println("==================");
            System.out.println("1. Create");
            System.out.println("2. Find and Sort");
            System.out.println("3. Update/Delete");
            System.out.println("4. Report");
            System.out.println("5. Exit");
            
            System.out.println("==================");
            System.out.println("STUDENT PROGRAM");
            
            int choice = manager.validate.inputInt("Enter your choice: ", 1, 5);

            switch (choice) {
                case 1:
                    manager.create();
                    break;
                case 2:
                    manager.findAndSort();
                    break;
                case 3:
                    manager.updateOrDelete();
                    break;
                case 4:
                    manager.report();
                    break;
                case 5:
                    System.exit(0);
            }
        }
    }
}
