package pkg0021v2;

import java.util.Scanner;
import java.util.HashSet;

public class Validate {

  private Scanner sc = new Scanner(System.in);
  private HashSet<String> studentIds = new HashSet<>();

  public String inputUniqueStudentId(String msg) {
    System.out.print(msg);
    
    while (true) {
        String input = sc.nextLine().trim(); // Trim any leading or trailing whitespace
        
        if (input.isEmpty()) {
            System.out.println("Please input a non-empty string");
            continue;
        }
        
        if (studentIds.contains(input)) {
            System.out.println("This student ID already exists. Please input a unique ID.");
            continue;
        }
        
        studentIds.add(input);
        return input;
    }
}


  public int inputInt(String msg, int min, int max) {
    System.out.print(msg);
    
    while (true) {
        String input = sc.nextLine().trim(); // Trim any leading or trailing whitespace
        
        try {
            int number = Integer.parseInt(input);
            if (number < min || number > max) {
                System.out.println("Please input a number between " + min + " and " + max + ".");
                continue;
            }
            return number;
        } catch (NumberFormatException ex) {
            System.out.println("Please input a valid integer number.");
        }
    }
}

  

public String inputString(String msg) {
    System.out.print(msg);
    while (true) {
      String input = sc.nextLine();
      if (input.isEmpty()) {
        System.out.println("Please input a non-empty string");
      } else {
        return input;
      }
    }
}

  public boolean checkUD(String msg) {
    System.out.print(msg);
    
    while (true) {
      String result = sc.nextLine();
      
        if (result.equalsIgnoreCase("U")) {
            return true;
            } else if (result.equalsIgnoreCase("D")) {
            return false;
            } else {
        System.err.println("You only have permission to update(U) or delete(D)");
        System.out.print(msg);
      }
    }
  }

  public String checkInputCourse(String msg) {
    System.out.print(msg);
    
    while (true) {
      String result = sc.nextLine();
      
      if (result.equalsIgnoreCase("java")
          || result.equalsIgnoreCase(".net")
          || result.equalsIgnoreCase("c/c++")) {
        return result;
        
      }
      System.out.println("There are only three courses: Java, .Net, C/C++");
      System.out.print("Enter again: ");
    }
  }
  
  public double inputDouble(String msg) {
      
    System.out.print(msg);
    while (true) {
        String input = sc.nextLine();
        try {
            double number = Double.parseDouble(input);
            return number;
        } catch (NumberFormatException e) {
            System.out.println("Please input a valid number:");
        }
    }
}
  public String inputStudentId(String msg) {
    System.out.print(msg);
    
    while (true) {
        String input = sc.nextLine().trim(); // Trim any leading or trailing whitespace
        
        if (input.isEmpty()) {
            System.out.println("Please input a non-empty string");
            continue;
        }
        
        return input;
    }
}
}
