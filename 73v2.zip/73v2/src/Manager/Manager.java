package Manager;

import java.util.ArrayList;
import Object.Expenses;
import java.text.SimpleDateFormat;
import java.util.Date;
import pkg73v2.Validation;

public class Manager {

    public static void addExpense(ArrayList<Expenses> expensesList, int id) {
        System.out.println("Adding an Expense:");
        System.out.print("Enter Date: ");
        Date date = Validation.checkInputDate();
        System.out.print("Enter Amount: ");
        double amount = Validation.checkInputDouble();
        System.out.print("Enter Content: ");
        String content = Validation.checkInputString();

        Expenses expense = new Expenses(id, date, amount, content);
        expensesList.add(expense);
        System.out.println("Expense added successfully!");
    }

    public static void displayExpenses(ArrayList<Expenses> expensesList) {
        if (expensesList.isEmpty()) {
            System.out.println("No expenses to display.");
        } else {
            System.out.println("| ID | Date                | Amount of money | Content            |");

            SimpleDateFormat dateFormat = new SimpleDateFormat("E MMM dd yyyy");

            for (Expenses expense : expensesList) {
                String formattedDate = dateFormat.format(expense.getDate());

                System.out.printf("| %-2d | %-20s | %-16.2f | %-18s |\n",
                        expense.getId(),
                        formattedDate,
                        expense.getAmount(),
                        expense.getContent());
            }
        }
    }

    


    public static void deleteExpense(ArrayList<Expenses> expensesList) {
       
        System.out.print("Enter the ID of the expense to delete: ");
        int id = Validation.checkInputInt();

        int index = Validation.checkInputInt();
        if( index != -1){
            expensesList.remove(index);
            System.out.println("delted");
        } else {
            System.out.println("id" + id +"not found");
        }
    }
    
    

    public static int checkIdExist(ArrayList<Expenses> expensesList, int id) {
        for(int i = 0; i < expensesList.size();i++){
            if( expensesList.get(i).getId() == id){
                return i;
            }
            
        }
        return -1;
    }
}
