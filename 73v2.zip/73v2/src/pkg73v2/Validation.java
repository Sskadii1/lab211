package pkg73v2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Validation {
    private static final Scanner in = new Scanner(System.in);

    public static int checkIntLimit(int min, int max) {
        int n = 0;
        while (true) {
            try {
                n = Integer.parseInt(in.nextLine());
                if (n < min || n > max) {
                    throw new NumberFormatException();
                }
                return n;
            } catch (NumberFormatException ex) {
                System.err.println("Re-input");
            }
        }
       
                
             
    }
    public static Date checkInputDate() {
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    dateFormat.setLenient(false); // This ensures strict date validation

    Scanner in = new Scanner(System.in);
    
    while (true) {
        String input = in.nextLine().trim();
        
        try {
            Date date = dateFormat.parse(input);
            return date;
        } catch (ParseException e) {
            System.err.println("Invalid date format. Please re-enter the date in the format dd/MM/yyyy");
        }
    }
}






    public static double checkInputDouble() {
        while (true) {
            try {
                return Double.parseDouble(in.nextLine());
            } catch (NumberFormatException ex) {
                System.err.println("Re-input");
            }
        }
    }

    public static String checkInputString() {
        while (true) {
            String result = in.nextLine().trim();
            if (!result.isEmpty()) {
                return result;
            } else {
                System.err.println("Re-input");
            }
        }
    }

    public static int checkInputInt() {
        while (true) {
            try {
                return Integer.parseInt(in.nextLine());
            } catch (NumberFormatException ex) {
                System.err.println("Re-input");
            }
        }
    }
}
