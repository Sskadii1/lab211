package pkg73v2;

import Object.Expenses;
import Manager.Manager;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws IOException {
        ArrayList<Expenses> expensesList = new ArrayList<>();
        int id = 0;

        while (true) {
            System.out.println("1. Add an expense");
            System.out.println("2. Display all expenses");
            System.out.println("3. Delete an expense");
            System.out.println("4. Quit");
            System.out.print("Your choice: ");
            int choice = Validation.checkIntLimit(1, 4);

            switch (choice) {
                case 1:
                    Manager.addExpense(expensesList, ++id);
                    break;
                case 2:
                    Manager.displayExpenses(expensesList);
                    break;
                case 3:
                    Manager.deleteExpense(expensesList);
                    id--;
                    break;
                case 4:
                    return;
            }
        }
    }
}
